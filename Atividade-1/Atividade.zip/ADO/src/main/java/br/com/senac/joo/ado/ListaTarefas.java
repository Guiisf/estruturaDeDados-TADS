/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.senac.joo.ado;

public class ListaTarefas {

    private String[] tarefas;
    private int numTarefas;
    private int capacidade;

    public ListaTarefas(int capacidade) {
        this.tarefas = new String[capacidade];
        this.numTarefas = 0;
        this.capacidade = capacidade;
    }

    public void adicionarTarefa(String tarefa) {
        if (this.numTarefas < this.capacidade) {
            this.tarefas[this.numTarefas] = tarefa;
            this.numTarefas++;
        } else {
            System.out.println("Não é possível adicionar mais tarefas.");
        }
    }

    public void removerTarefa(int indice) {
        if (indice < this.numTarefas) {
            for (int i = indice; i < this.numTarefas - 1; i++) {
                this.tarefas[i] = this.tarefas[i + 1];
            }
            this.numTarefas--;
        } else {
            System.out.println("Índice inválido.");
        }
    }

    public void exibirTarefas() {
        for (int i = 0; i < this.numTarefas; i++) {
            System.out.println((i + 1) + ". " + this.tarefas[i]);
        }
    }

    public int getNumTarefas() {
        return this.numTarefas;
    }

    public String getTarefa(int indice) {
        return this.tarefas[indice];
    }
}
